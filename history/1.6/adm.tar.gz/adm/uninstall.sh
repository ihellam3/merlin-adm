#!/bin/sh

sh /koolshare/adm/adm.sh stop
rm -rf /koolshare/adm
rm -rf /koolshare/init.d/S60adm.sh
rm -rf /koolshare/scripts/adm_*.sh
rm -rf /koolshare/webs/Module_adm.asp

